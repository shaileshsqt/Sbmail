import React, { useReducer } from "react";
import EmailContext from "./emailContext";
import EmailReducer from "./emailReducer";
import axios from "axios";
import {
  SET_MESSAGE,
  SET_MESSAGES,
  CLEAR_MESSAGES,
  SET_LOADING,
  SET_CURRENT_LABEL,
  SET_NEXT_PAGE_TOKEN,
  SET_HAS_MORE_MESSAGES,
} from "../types";

const EmailState = (props) => {
  const initialState = {
    messages: [],
    message: null,
    currentLabel: "INBOX",
    nextPageToken: "",
    hasMoreMessages: true,
    isAuthorize: false,
    loading: false,
  };

  const [state, dispatch] = useReducer(EmailReducer, initialState);
  const userId = JSON.parse(localStorage.getItem("UserInfo"));
  console.log("User info::::", userId.email);
  const Token = JSON.parse(localStorage.getItem("Token"));
  console.log("Token::::", Token.access_token);
  // Send reques to get IDs of 20 Messages and call getMessagesData(Ids)
  const getMessages = async (labelIds = state.currentLabel) => {
    // Set Loading to true
    setLoading();

    // Empty previous messages
    clearMessages();
    try {
      debugger;
      const getmess = await axios.get(
        `https://gmail.googleapis.com/gmail/v1/users/${userId.email}/messages`,
        { headers: { Authorization: `Bearer ${Token.access_token}` } },
        {
          params: {
            labelIds: labelIds,
            maxResults: 20,
          },
        }
      );

      if (getmess.data.nextPageToken) {
        setNextPageToken(getmess.data.nextPageToken);
        setHasMoreMessages(true);
      } else {
        setNextPageToken("");
        setHasMoreMessages(false);
      }
      getMessagesData(getmess.data);

      console.log("Get Meesage **", getmess.data);
    } catch (error) {
      console.log("Get Message Error", error);
    }

    // const request = window.gapi.client.gmail.users.messages.list({
    //   userId: "me",
    //   labelIds: labelIds,
    //   maxResults: 20,
    // });

    //  await axios
    //    .get(`https://gmail.googleapis.com/gmail/v1/users/me/messages`, {
    //      access_token: res.access_token,
    //    })
    //    .then((response) => {
    //      setPost(response.data);
    //    });

    // const GetList = await axios.get(
    //   "https://gmail.googleapis.com/gmail/v1/users/me/messages",
    //   { headers: { Authorization: "Bearer <tokenResponse.access_token>" } }
    // );

    // request.execute((resp) => {
    //   console.log("set token response", resp);
    // Set NextPageToken

    // Send Id list to getMessagesData to get Message Data foreach Id
    // });
  };

  const getMessagesQuery = (query) => {
    // Set Loading to true
    setLoading();

    // Empty previous messages
    clearMessages();

    // Get List of 20 message's Id
    const request = window.gapi.client.gmail.users.messages.list({
      userId: "me",
      q: query,
    });

    // Send Id list to getMessagesData to get Message Data foreach Id
    request.execute(getMessagesData);
  };

  async function trail(params) {
    let res = await axios.get(
      `https://gmail.googleapis.com/gmail/v1/users/${userId.email}/messages/${params.id}`,
      { headers: { Authorization: `Bearer ${Token.access_token}` } }
    );
    return res;
  }

  // Send Request to get data of each message
  const getMessagesData = async (resp) => {
    debugger;
    const messages = resp?.messages ? await resp?.messages : [];

    // Get Data for each message
    messages.forEach(async (message) => {
      let myRes = await trail(message);
      console.log("Data", myRes.data);
      dispatch({
        type: SET_MESSAGES,
        payload: myRes.data,
      });
      // try {
      //   let resp = axios.get(
      //     `https://gmail.googleapis.com/gmail/v1/users/${userId.email}/messages${message.id}`,
      //     { headers: { Authorization: `Bearer ${Token.access_token}` } }
      //   );
      //   console.log("GET MESSAGE DATA ?????", resp);
      //
      // } catch (error) {
      //   console.log("Error", error);
      // }

      // const request = window.gapi.client.gmail.users.messages.get({
      //   userId: "me",
      //   id: message.id,
      // });

      // request.execute((resp) => {
      //   dispatch({
      //     type: SET_MESSAGES,
      //     payload: resp.result,
      //   });
      // });
    });
  };

  // Get Message
  const getOneMessage = async (messageId) => {
    try {
      let getOneMessage = await axios.get(
        `https://gmail.googleapis.com/gmail/v1/users/${userId.email}/messages/${messageId}`,
        { headers: { Authorization: `Bearer ${Token.access_token}` } }
      );
      console.log("getOneMessage", getOneMessage);
      dispatch({
        type: SET_MESSAGE,
        payload: getOneMessage.data,
      });
      // then((resp) => {
      //     console.log("resp", resp);
      //
      //   });
    } catch (error) {
      console.log("Error", error);
    }
  };

  // Load More Messages
  const loadMoreMessages = async (labelIds = state.currentLabel) => {
    try {
      let moremessage = await axios.get(
        `https://gmail.googleapis.com/gmail/v1/users/${userId.email}/messages`,
        { headers: { Authorization: `Bearer ${Token.access_token}` } },
        {
          params: {
            labelIds: labelIds,
            maxResults: 10,
            pageToken: state.nextPageToken,
          },
        }
      );
      console.log("moremessage??", moremessage);
      // .then((resp) => {
      //   if (resp.result.nextPageToken) {
      //     setNextPageToken(resp.result.nextPageToken);
      //     setHasMoreMessages(true);
      //   } else {
      //     setNextPageToken("");
      //     setHasMoreMessages(false);
      //   }

      //   getMessagesData(resp);
      // });
    } catch (error) {}
  };

  // Set Next Page Token
  const setNextPageToken = (token) =>
    dispatch({ type: SET_NEXT_PAGE_TOKEN, payload: token });

  // Set Has More Messages
  const setHasMoreMessages = (bool) =>
    dispatch({ type: SET_HAS_MORE_MESSAGES, payload: bool });

  // Set Current Label
  const setCurrentLabel = (labelId) =>
    dispatch({ type: SET_CURRENT_LABEL, payload: labelId });

  // Clear Messages
  const clearMessages = () => dispatch({ type: CLEAR_MESSAGES });

  // Set Loading
  const setLoading = () => dispatch({ type: SET_LOADING });

  return (
    <EmailContext.Provider
      value={{
        messages: state.messages,
        message: state.message,
        currentLabel: state.currentLabel,
        nextPageToken: state.nextPageToken,
        hasMoreMessages: state.hasMoreMessages,
        loading: state.loading,
        getMessages,
        getMessagesQuery,
        getOneMessage,
        setCurrentLabel,
        loadMoreMessages,
        setLoading,
      }}
    >
      {props.children}
    </EmailContext.Provider>
  );
};

export default EmailState;
