import { createContext } from "react";

const emailContext = createContext();
    
export default emailContext;
