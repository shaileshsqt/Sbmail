import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import { GoogleOAuthProvider } from "@react-oauth/google";

const REACT_APP_CLIENT_ID =
  "1064787533834-472sbp8tf217mfmbeoqq0pjoinq9okaf.apps.googleusercontent.com";

ReactDOM.render(
  <GoogleOAuthProvider clientId="1064787533834-472sbp8tf217mfmbeoqq0pjoinq9okaf.apps.googleusercontent.com">
    <App />
  </GoogleOAuthProvider>,

  document.getElementById("root")
);
