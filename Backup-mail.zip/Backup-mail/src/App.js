import React, { useEffect, useState } from "react";

// Import Context
import EmailState from "./context/email/EmailState";

// Import Pages
import Main from "./pages/Main";
import SignIn from "./pages/SignIn";

import { ThemeProvider, CSSReset } from "@chakra-ui/core";

// auth google
import { GoogleLogin, useGoogleLogin } from "@react-oauth/google";
import axios from "axios";

const App = () => {
  const [isAuthorize, setIsAuthorize] = useState(false);
  const [loading, setLoading] = useState(false);
  const [accessToken, setAccessToken] = useState(null);

  // const REACT_APP_CLIENT_ID =
  //   "1064787533834-472sbp8tf217mfmbeoqq0pjoinq9okaf.apps.googleusercontent.com";
  // const REACT_APP_API_KEY = "AIzaSyAYxn_C61J2W5eUnJlPi_-N6Yd1rV8FFXo";
  // const DISCOVERY_DOC =
  //   "https://www.googleapis.com/discovery/v1/apis/gmail/v1/rest";
  // const REACT_APP_SCOPES = "https://mail.google.com/";
  // const REACT_REDIRECT_URI = "http://localhost:3000";

  const REACT_APP_CLIENT_ID = process.env.REACT_APP_CLIENT_ID;
  const REACT_APP_API_KEY = process.env.REACT_APP_API_KEY;
  const DISCOVERY_DOC = process.env.DISCOVERY_DOC;
  const REACT_APP_SCOPES = process.env.REACT_APP_SCOPES;
  const REACT_REDIRECT_URI = process.env.REACT_REDIRECT_URI;
  // useEffect(() => {
  //   setLoading(true);

  //   const initialGoogleConnection = async () => {
  //     await window.gapi.load("client:auth2", {
  //       callback: () => {
  //         // Handle gapi.client initialization.
  //         window.gapi.client.setApiKey(REACT_APP_API_KEY);
  //         window.gapi.auth.authorize(
  //           {
  //             client_id: REACT_APP_CLIENT_ID,
  //             scope: REACT_APP_SCOPES,
  //             immediate: true,
  //           },
  //           handleAuthResult
  //         );
  //       },
  //       onerror: function () {
  //         // Handle loading error.
  //         console.log("gapi.client failed to load!");
  //       },
  //       timeout: 5000, // 5 seconds.
  //       ontimeout: function () {
  //         // Handle timeout.
  //         console.log("gapi.client could not load in a timely manner!");
  //       },
  //     });
  //   };

  //   try {
  //     initialGoogleConnection();
  //   } catch (error) {
  //     console.log("error: ", error);
  //   }

  //   setLoading(false);
  //   // eslint-disable-next-line
  // }, []);

  const googleLogin = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      console.log(tokenResponse);
      setAccessToken(tokenResponse);
      localStorage.setItem("Token", JSON.stringify(tokenResponse));

      const userInfo = await axios.get(
        "https://www.googleapis.com/oauth2/v3/userinfo",
        { headers: { Authorization: `Bearer ${tokenResponse.access_token}` } }
      );
      console.log("Userinbfo", userInfo);

      const gmailDemo = await axios.get(
        `https://gmail.googleapis.com/gmail/v1/users/${userInfo.data.email}/messages`,
        {
          headers: { Authorization: `Bearer ${tokenResponse.access_token}` },
        },
        {
          params: {
            labelIds: "INBOX",
            maxResults: 20,
          },
        }
      );

      localStorage.setItem("UserInfo", JSON.stringify(userInfo.data));
      console.log("!!!!!!!!!!!!!!", gmailDemo);
      setIsAuthorize(true);
    },
    onError: (errorResponse) => console.log(errorResponse),
    isSignedIn: true,
    accessType: "offline",
    scope: REACT_APP_SCOPES,
    // responseType: "code",
    prompt: "consent",
    // flow: "auth-code",
  });

  // const googleSignIn = useGoogleLogin({
  //   onSuccess,
  //   onFailure,
  //   isSignedIn: true,
  //   accessType: "offline",
  //   scope: REACT_APP_SCOPES,
  //   responseType: "code",
  //   prompt: "consent",
  //   flow: "auth-code",
  // });

  // const onSuccess = (response) => {
  //   console.log("OAuth login successful. Access token:", response.accessToken);
  //   setAccessToken(response.accessToken);
  //   setIsAuthorize(true);
  //   // You can now use the access token for API requests
  // };

  // const onFailure = (error) => {
  //   console.error("OAuth login failed. Error:", error);
  // };

  const handleAuthResult = (authResult) => {
    if (authResult && !authResult.error) {
      console.log("Sign-in successful");
      // setIsAuthorize(true);
      loadClient();
    } else {
      console.error("handleAuthResult...");
      console.error(authResult);
    }
    setLoading(false);
  };

  const handleAuthClick = () => {
    setLoading(true);
    return window.gapi.auth.authorize(
      {
        client_id: REACT_APP_CLIENT_ID,
        scope: REACT_APP_SCOPES,
        immediate: false,
      },
      handleAuthResult
    );
  };

  const loadClient = () => {
    return window.gapi.client.load("gmail", "v1").then(
      (res) => {
        console.log("gapi client loaded for API");
        setIsAuthorize(true);
        // getMessages();
      },
      (err) => {
        console.error("Error loading window.gapi client for API", err);
      }
    );
  };

  return (
    <EmailState>
      <ThemeProvider>
        <CSSReset />
        {isAuthorize ? (
          <Main />
        ) : (
          <SignIn loading={loading} handleAuthClick={googleLogin} />
          // <GoogleLogin
          //   // clientId={REACT_APP_CLIENT_ID}
          //   buttonText="Login with Google"
          //   onSuccess={onSuccess}
          //   onFailure={onFailure}
          //   // cookiePolicy={"single_host_origin"}
          // />
        )}
      </ThemeProvider>
    </EmailState>
  );
};

export default App;
